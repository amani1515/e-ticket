@extends('hisabShum.layouts.app')

@section('title', 'Hisab Shum')

@section('content')
    <h2 class="text-xl font-semibold mb-4">Welcome to Hisab Shum</h2>
    <!-- Your functions/content will go here -->
@endsection